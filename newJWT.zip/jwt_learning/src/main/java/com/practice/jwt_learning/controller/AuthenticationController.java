package com.practice.jwt_learning.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.practice.jwt_learning.entity.AuthenticationResponse;
import com.practice.jwt_learning.entity.Users;
import com.practice.jwt_learning.service.AuthenticationService;

@RestController
public class AuthenticationController {
	
	@Autowired
	private AuthenticationService service;
	
	@PostMapping("/register")
	public ResponseEntity<AuthenticationResponse> register(@RequestBody Users users){
		return ResponseEntity.ok(service.register(users));
	}

	@PostMapping("/login")
	public ResponseEntity<AuthenticationResponse> login(@RequestBody Users users){
		return ResponseEntity.ok(service.authenticate(users));
	}

}
