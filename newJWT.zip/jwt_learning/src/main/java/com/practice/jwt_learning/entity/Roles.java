package com.practice.jwt_learning.entity;

public enum Roles {
	User,
	Admin

}
