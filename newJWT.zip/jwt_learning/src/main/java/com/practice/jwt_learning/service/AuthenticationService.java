package com.practice.jwt_learning.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.practice.jwt_learning.entity.AuthenticationResponse;
import com.practice.jwt_learning.entity.Users;
import com.practice.jwt_learning.repository.UsersRepository;

@Service
public class AuthenticationService {
	
	@Autowired
	private UsersRepository repo;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Autowired
	private JwtService service;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	
	public AuthenticationResponse register(Users request) {
		Users users=new Users();
		users.setFname(request.getFname());
		users.setLname(request.getLname());
		users.setUsername(request.getUsername());
		users.setPassword(passwordEncoder.encode(request.getPassword()));
		users.setRole(request.getRole());
		users=repo.save(users);
		String token=service.generateToken(users);
		return new AuthenticationResponse(token);
		
	}
	
	public AuthenticationResponse authenticate(Users request) {
		authenticationManager.authenticate(
				new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword())
				
				);
		Users users=repo.findByUsername(request.getUsername()).orElseThrow();
		
		String token=service.generateToken(users);
		return new AuthenticationResponse(token);
	}
	
	
}
